---
title: Bon appétit!
---

Page titles with accents are supported.
